DON'T BE  PANIC. THIS IS THE FIRST TIME I USE GIT.
浮云终日行， 游子久不至。 
三夜频梦君， 情亲见君意。 
告归常局促， 苦道来不易： 
江湖多风波， 舟楫恐失坠。 
出门搔白首， 若负平生志。 
冠盖满京华， 斯人独憔悴！ 
孰云网恢恢？ 将老身反累！ 
千秋万岁名， 寂寞身后事。

指间沙 
一切都像指间沙
不要用力 不要试图把握
所有的把握只能加速一种失去
就像我们手指间的沙
沙子们最后都走了
留下我们的手 孤独地停在半空中
所有的手都走了 
曾经闪光的不是手 留下的也不是手
而是指间沙

In the End, we will remember not the words of our enemies, but the silence of our friends.
----Martin Luther King, Jr.

ごとぐと手（て）を结（むす）んだあの子（こ）は最期（さいご）.. 笑（わら）ってた 
降（ふ）リ积（つ）もる雪（ゆき）たちは
time to say goodbye 
